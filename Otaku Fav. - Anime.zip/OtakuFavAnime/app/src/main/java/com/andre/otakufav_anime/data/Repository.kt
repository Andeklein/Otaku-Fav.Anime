package com.andre.otakufav_anime.data

class Repository() {
}